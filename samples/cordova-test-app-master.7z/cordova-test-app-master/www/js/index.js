(function() {
    'use strict';

    document.addEventListener('deviceready', onDeviceReady, false);

    function onDeviceReady() {
        if (typeof(device) !== 'undefined') {
            // Display device information
		}
           

        // Wire-up the form
        var theForm = document.getElementById('theForm');

        // Get the previous URL from local storage
        //if (typeof(localStorage) !== 'undefined') {
        //    theUrl.value = localStorage['cordova-test-app-url'] || '';
        //}

        // When the form is submitted, redirect to the given URL
        theForm.onsubmit = function(evt) {
			try{
			
			function HMAC(message, key) {
				var hmac = "";
				try {
					var shaObj = new jsSHA("SHA-256", "TEXT");
					shaObj.setHMACKey(key, "HEX");
					shaObj.update(message);
					hmac = shaObj.getHMAC("HEX");
					}
				catch(err) {
					alert(err);
					
				}
				return hmac.toUpperCase();
			}
			
            // Save the URL to local storage to pre-populate next time
            //if (typeof(localStorage) !== 'undefined') {
            //    localStorage['cordova-test-app-url'] = theUrl.value;
            //}
			//android sdk code
			function sendResponseParameters()
			{
				try{
				var data=theForm.elements;
				var url = "https://uat.pinepg.in/PinePGRedirect/index";
				var formID = "PostForm";
				var strForm = "<form id=\"" + formID + "\" name=\"" + formID + "\" action=\"" + url + "\" method=\"POST\">"
				var msgString = "";

				var dict1={};
				for(var i=0;i<data.length;i++)
				{
					dict1[data[i].name]=data[i].value;
				}
				data=dict1;
				var keys = Object.keys(data);
				keys.sort();
				for (var i = 0; i < keys.length; i++) {
					var key = keys[i];
					if (data[key] != null && data[key] != undefined && key != 'ppc_DIA_SECRET' && key != 'ppc_DIA_SECRET_TYPE') {
						msgString += String(key) + "=" + String(data[key]) + "&";
						}
				}
				msgString = msgString.slice(2, -1);
				var strSecretKey = "08316C4FE4DD4CC887ED8A70B4B41E22";
				var strHashType = "SHA256";
				var strDIA_SECRET = HMAC(msgString, strSecretKey);
				//if hash generation failed
				if (strDIA_SECRET == "") {
					alert("<h1>Hash generation failed</h1>");
				} else 
				{
					data['ppc_DIA_SECRET'] = strDIA_SECRET
					data['ppc_DIA_SECRET_TYPE'] = strHashType
					for (key in data) {
						if (data[key] != null && data[key] != undefined) {
							strForm += "<input type=\"hidden\" name=\"" + key + "\" value=\"" + data[key] + "\">";
					}
				}
				strForm += "</form>";
				var strScript = "<script language='javascript'>";
				strScript += "var v" + formID + " = document." + formID + ";";
				strScript += "v" + formID + ".submit();";
				strScript += "</script>";
				//alert(strForm + strScript);
				//theForm.submit();
				document.write(strForm + strScript);
				}
				}
				catch(err)
				{
					alert(err);
				}
			}
			sendResponseParameters();
			
			
			
			

            // Go there
            // NOTE: iOS & Android will load this URL in the Cordova webview (which is what we want).
            //       But Windows Phone will launch IE and open the URL (which defeats the whole purpose)  :( 
            //window.location = theUrl.value;
            
            // Don't actually submit the form
            evt.preventDefault();
			}
			catch(err)
			{
				alert(err);
			}
        };
    }
})();
