<?php

namespace Pinelabs\PinePGGateway\Controller\Standard;

use Magento\Sales\Model\Order\Email\Sender\OrderSender;

class Response extends \Pinelabs\PinePGGateway\Controller\PinePGAbstract {
  
 
    
    public function execute() {
		
        $returnUrl = $this->getCheckoutHelper()->getUrl('checkout');
        try {
            $paymentMethod = $this->getPaymentMethod();
            $params = $this->getRequest()->getParams();

            if ($paymentMethod->validateResponse($params)) {
				
                $returnUrl = $this->getCheckoutHelper()->getUrl('checkout/onepage/success');
				$order_id = trim(($params['ppc_UniqueMerchantTxnID']));
				
		      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			  
             	$order = $objectManager->create('Magento\Sales\Api\Data\OrderInterface')->loadByIncrementId($order_id);
				
				$order->setState('processing')->setStatus('processing');
					
					$order->save();
					
                //$order = $this->getOrder();
                $payment = $order->getPayment();
				
                $paymentMethod->postProcessing($order, $payment, $params);
				
				$returnUrl = $this->getCheckoutHelper()->getUrl('checkout/onepage/success');
				
				  try {
					    $orderSender=$objectManager->create('Magento\Sales\Model\Order\Email\Sender\OrderSender');
						$orderSender->send($order);
				     } 			
					 catch (\Exception $e) 
					 {
					  $this->logger->critical($e);
					 }
            } 
			else {
				$returnUrl = $this->getCheckoutHelper()->getUrl('checkout/onepage/failure');
				 $this->_cancelPayment('Payment fails');
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addExceptionMessage($e, $e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('We can\'t place the order.'));
        }

        $this->getResponse()->setRedirect($returnUrl);
    }

}
