var express = require('express');

var testmerchantRouter = require('./testmerchant');

var app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//Any url-pattern that matches '/testmerchant' is redirected to be handled by 'testmerchantRouter'
app.use('/testmerchant', testmerchantRouter);

//Set the address(port, ip) on which the server listens
app.listen(8000, '127.0.0.1');