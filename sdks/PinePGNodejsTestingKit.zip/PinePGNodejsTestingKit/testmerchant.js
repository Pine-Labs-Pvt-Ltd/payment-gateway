function HMAC(message, key) {
    var hmac = "";
	
	try {
	    var shaObj = new jsSHA("SHA-256", "TEXT");
	    shaObj.setHMACKey(key, "HEX");
	    shaObj.update(message);
	    hmac = shaObj.getHMAC("HEX");
    }
    catch(err) {
    }

    return hmac.toUpperCase();
}

var path = require('path');
var jsSHA = require("jssha");
var express = require('express');

var router = express.Router();

//Setting the routes
router.get('/MerchantTestPage', function(req, res, next) {
	res.sendFile(path.join(__dirname, '/merchantTestPage.html'));
});

router.post('/MerchantTestPage', function(req, res, next) {
 	var data = req.body;

	var url = "https://uat.pinepg.in/PinePGRedirect/index";
	var formID = "PostForm";
	
	strForm = "<form id=\"" + formID + "\" name=\"" + formID + "\" action=\"" + url + "\" method=\"POST\">"

 	var msgString = "";
	var keys = Object.keys(data);

	keys.sort();

	for (var i = 0; i < keys.length; i++) {
		var key = keys[i];
		if (data[key] != null && data[key] != undefined && key != 'ppc_DIA_SECRET' && key != 'ppc_DIA_SECRET_TYPE') {
			msgString += String(key) + "=" + String(data[key]) + "&";
		}
	}

 	msgString = msgString.slice(0, -1);
	
	strSecretKey = "46AC6117F2104F91B554F3E35DCEFE41"
	strHashType = "SHA256"

	strDIA_SECRET = HMAC(msgString, strSecretKey);

	//if hash generation failed
	if (strDIA_SECRET == "") {
		res.send("<h1>Error!</h1>");
	} else {
		data['ppc_DIA_SECRET'] = strDIA_SECRET
		data['ppc_DIA_SECRET_TYPE'] = strHashType

		for (key in data) {
			if (data[key] != null && data[key] != undefined) {
				strForm += "<input type=\"hidden\" name=\"" + key + "\" value=\"" + data[key] + "\">";
			}
		}
		strForm += "</form>";

		strScript = "<script language='javascript'>";
		strScript += "var v" + formID + " = document." + formID + ";";
		strScript += "v" + formID + ".submit();";
		strScript += "</script>";

		res.send(strForm + strScript);
	}
});

router.post('/MerchantResponsePage', function(req, res, next) {
	strMsgResponse = "<h1> RESPONSE PARAMETERS </h1>";

	data = req.body;
	
	var keys = Object.keys(data);
	keys.sort();

	for (var i = 0; i < keys.length; i++) {
		var key = keys[i];
		strMsgResponse += "<strong>" + key + "</strong>" + " = " + data[key] +"<BR />";
	}
	
	msgString = "";
	
	for (var i = 0; i < keys.length; i++) {
		var key = keys[i];
		if (data[key] != null && data[key] != undefined && key != 'ppc_DIA_SECRET' && key != 'ppc_DIA_SECRET_TYPE') {
			msgString += String(key) + "=" + String(data[key]) + "&";
		}
	}

 	msgString = msgString.slice(0, -1);
	
	strSecretKey = "46AC6117F2104F91B554F3E35DCEFE41";
	strHashType = "SHA256";

	strDIA_SECRET = HMAC(msgString, strSecretKey);

	strMsgResponse += "<BR /><strong>" + "Hash Generated on Response Page" + "</strong>" + " = " + strDIA_SECRET +"<BR />";
	strMsgResponse += "<strong>" + "Do Hashes match?: " + "</strong>";

	comment = "";

	if (strDIA_SECRET == data['ppc_DIA_SECRET']) {
	//Transaction is successful if ppc_TxnResponseCode = 1
		if (data['ppc_TxnResponseCode'] == "1") {
			comment = "Transaction SUCCESSFUL";
			strMsgResponse += "YES" + "<BR />";
		} else {
			comment = "Transaction UNSUCCESSFUL";
			strMsgResponse += "YES" + "<BR />";
		}
	} else {
		comment = "Transaction UNSUCCESSFUL";//	#because hashes do not match
		strMsgResponse += "NO" + "<BR />";
	}
	strMsgResponse += "<BR />" + "<h4>" + comment + "</h4>" + "<BR />";

	res.send(strMsgResponse);
});

module.exports = router;