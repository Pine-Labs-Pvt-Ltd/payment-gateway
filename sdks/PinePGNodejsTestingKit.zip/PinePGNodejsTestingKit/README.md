----------------------------To run the kit as a standalone application------------------------

-In the terminal/command-prompt, go to the directory containing the testing kit 'PinePGNodejsTestingKit'

-Then run:
	cd PinePGNodejsTestingKit

-To install the required dependencies('express' and 'jssha'), run:
	npm install

-You can set the address(port, ip) on which the server(app) is listening in the app.js file

-Then in cmd, run:
	node app.js

-Now, ASSUMING the server listens on http://127.0.0.1:8000, to access the Merchant Test Page, go to:
	http://127.0.0.1:8000/testmerchant/MerchantTestPage/

-In the 'ppc_MerchantReturnURL' parameter, enter the server address followed by '/testmerchant/MerchantResponsePage/' (without quotes)

-So, if the server is listening on http://127.0.0.1:8000, you have to enter:
	http://127.0.0.1:8000/testmerchant/MerchantResponsePage/


----------------------------To integrate it in your application-------------------------------

-If not already installed, then install the following dependencies:
1) 'express':
		npm install express

2) 'jssha':
		npm install jssha

-As shown in app.js file, import the 'testmerchant.js' file present in 'routes' folder in your express app:
	var testmerchantRouter = require('./routes/testmerchant');

-Assuming 'app' is your express application, use the above router object as:
	app.use('/testmerchant', testmerchantRouter);

-Now any url-pattern that matches '/testmerchant' is redirected to be handled by 'testmerchantRouter'

eg:
1) GET:	'/testmerchant/MerchantTestPage'

2) POST: '/testmerchant/MerchantTestPage'

3) POST: '/testmerchant/MerchantResponsePage'

-Restart your application

-Now, ASSUMING the server listens on http://127.0.0.1:8000, to access the Merchant Testing Page, go to:
	http://127.0.0.1:8000/testmerchant/MerchantTestPage/

-In the 'ppc_MerchantReturnURL' parameter, enter the server address followed by '/testmerchant/MerchantResponsePage/' (without quotes)

-So, if the server is listening on http://127.0.0.1:8000/, you have to enter:
	http://127.0.0.1:8000/testmerchant/MerchantResponsePage/
